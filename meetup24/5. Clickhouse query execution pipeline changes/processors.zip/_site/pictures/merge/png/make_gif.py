import os
import imageio

png_dir = '.'
images = []
for n in range(18):
        file_path = os.path.join('merge_{}.svg.png'.format(n))
        for i in range(6):
          images.append(imageio.imread(file_path))
imageio.mimsave('merge_main.gif', images)